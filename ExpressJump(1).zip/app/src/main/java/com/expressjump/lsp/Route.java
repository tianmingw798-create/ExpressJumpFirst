package com.expressjump.lsp;

import android.content.Context;
import android.content.SharedPreferences;

import com.expressjump.core.Kit;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import dalvik.system.DexFile;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/**
 * 路由层（第一原则：零硬编码类名/方法名/页面路径，特征扫描+动态匹配）：
 *
 * RouteLocator  路由单例定位：
 *               DexFile枚举 → 包名前缀+类名特征词过滤 → 结构打分
 *               （单例结构+String首参跳转方法+双String注册方法），最高分者胜。
 *               结果按(包名, versionCode)缓存，APP升级自动失效重扫 → 天然抗混淆。
 *
 * RouteStore    路径仓库：
 *               被动捕获 —— Hook路由单例注册方法，路由表加载时收集path；
 *               主动收割 —— 反射遍历单例内部Map字段（路由表本质是Map<path,target>）；
 *               关键词打分匹配 + 按版本键控的持久缓存（升级自动重匹，无需人工改链接）。
 */
public final class Route {

    // ==================== 路由单例定位 ====================

    public static final class Locator {
        public static final class Handle {
            public Class<?> routerClass;
            public Object routerInstance;                 // 可能为null（纯静态路由）
            public Method jumpMethod;
            public List<Method> registerMethods = new ArrayList<>();
        }

        private static final ConcurrentHashMap<String, Handle> HANDLES = new ConcurrentHashMap<>();
        private static final ConcurrentHashMap<String, Long> VERSIONS = new ConcurrentHashMap<>();

        public static Handle locate(Context ctx, LspCore.Config cfg) {
            String key = cfg.packageName;
            long ver = version(ctx);
            try {
                Long cached = VERSIONS.get(key);
                if (cached != null && cached == ver && HANDLES.containsKey(key)) {
                    return HANDLES.get(key);
                }
                Handle h = doScan(ctx, cfg);
                if (h != null) {
                    HANDLES.put(key, h);
                    VERSIONS.put(key, ver);
                    Kit.Logger.i("[" + cfg.appName + "] 路由定位成功: " + h.routerClass.getName());
                }
                return h;
            } catch (Throwable t) {
                Kit.Logger.e("[" + cfg.appName + "] 路由定位失败", t);
                return null;
            }
        }

        private static long version(Context ctx) {
            try {
                return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0)
                        .getLongVersionCode();
            } catch (Throwable t) { return -1; }
        }

        private static Handle doScan(Context ctx, LspCore.Config cfg) throws Throwable {
            DexFile dex = new DexFile(ctx.getApplicationInfo().sourceDir);
            ClassLoader cl = ctx.getClassLoader();
            java.util.Enumeration<String> entries = dex.entries();

            Class<?> bestClass = null;
            int bestScore = 0;
            while (entries.hasMoreElements()) {
                String name = entries.nextElement();
                try {
                    if (!matchPrefix(name, cfg.scanPrefixes)) continue;
                    if (!containsAny(name, cfg.routerNameHints)) continue;
                    Class<?> clz = Class.forName(name, false, cl);
                    if (clz.isInterface() || Modifier.isAbstract(clz.getModifiers())) continue;
                    int score = score(clz, cfg);
                    if (score > bestScore) { bestScore = score; bestClass = clz; }
                } catch (Throwable ignored) { /* 单类失败不影响整体 */ }
            }

            if (bestClass == null || bestScore < 6) return null; // 三者齐备至少6分
            Handle h = new Handle();
            h.routerClass = bestClass;
            resolve(h, cfg);
            return h.jumpMethod != null ? h : null;
        }

        /** 结构打分：单例+3 跳转方法+2 注册方法+2 类名强先验+1（三者齐备至少6） */
        private static int score(Class<?> clz, LspCore.Config cfg) {
            boolean singleton = false, jump = false, reg = false;
            for (Method m : clz.getDeclaredMethods()) {
                try {
                    if (Modifier.isStatic(m.getModifiers()) && m.getParameterTypes().length == 0
                            && clz.isAssignableFrom(m.getReturnType())
                            && m.getName().toLowerCase().matches(".*(getinstance|instance|of|get).*")) {
                        singleton = true;
                    }
                    if (!Modifier.isPublic(m.getModifiers())) continue;
                    Class<?>[] pts = m.getParameterTypes();
                    if (pts.length >= 1 && pts[0] == String.class
                            && (containsAny(m.getName(), cfg.navMethodHints) || pts.length <= 2)) {
                        jump = true; // 名称吻合 或 签名结构吻合（混淆后方法名随机）
                    }
                    if (pts.length >= 2 && pts[0] == String.class
                            && (pts[1] == String.class || pts[1] == Class.class
                                || containsAny(m.getName(), cfg.registerHints))) {
                        reg = true;
                    }
                } catch (Throwable ignored) {}
            }
            if (!singleton) {
                for (Field f : clz.getDeclaredFields()) {
                    try {
                        if (Modifier.isStatic(f.getModifiers()) && clz.isAssignableFrom(f.getType())) {
                            singleton = true; break;
                        }
                    } catch (Throwable ignored) {}
                }
            }
            if (!(singleton && jump && reg)) return 0;
            int s = 5;
            String n = clz.getSimpleName().toLowerCase();
            if (n.endsWith("router") || n.endsWith("route") || n.endsWith("dispatcher")) s += 1;
            return s;
        }

        private static void resolve(Handle h, LspCore.Config cfg) {
            Class<?> clz = h.routerClass;
            try {
                // 单例实例：静态方法优先，静态字段次之
                for (Method m : clz.getDeclaredMethods()) {
                    try {
                        if (Modifier.isStatic(m.getModifiers()) && m.getParameterTypes().length == 0
                                && clz.isAssignableFrom(m.getReturnType())) {
                            m.setAccessible(true);
                            Object inst = m.invoke(null);
                            if (inst != null) { h.routerInstance = inst; break; }
                        }
                    } catch (Throwable ignored) {}
                }
                if (h.routerInstance == null) {
                    for (Field f : clz.getDeclaredFields()) {
                        try {
                            if (Modifier.isStatic(f.getModifiers()) && clz.isAssignableFrom(f.getType())) {
                                f.setAccessible(true);
                                Object inst = f.get(null);
                                if (inst != null) { h.routerInstance = inst; break; }
                            }
                        } catch (Throwable ignored) {}
                    }
                }
                // 主跳转方法：优先名称特征词，其次首参String的公开方法
                Method best = null;
                for (Method m : clz.getDeclaredMethods()) {
                    try {
                        if (!Modifier.isPublic(m.getModifiers())) continue;
                        Class<?>[] pts = m.getParameterTypes();
                        if (pts.length < 1 || pts[0] != String.class) continue;
                        if (containsAny(m.getName(), cfg.navMethodHints)) { best = m; break; }
                        if (best == null && pts.length <= 3) best = m;
                    } catch (Throwable ignored) {}
                }
                if (best != null) { best.setAccessible(true); h.jumpMethod = best; }

                // 注册方法收集（路径捕获用）
                for (Method m : clz.getDeclaredMethods()) {
                    try {
                        if (!Modifier.isPublic(m.getModifiers())) continue;
                        Class<?>[] pts = m.getParameterTypes();
                        if (pts.length >= 2 && pts[0] == String.class
                                && (pts[1] == String.class || pts[1] == Class.class)) {
                            m.setAccessible(true);
                            h.registerMethods.add(m);
                        }
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable t) {
                Kit.Logger.e("解析路由实例失败: " + clz.getName(), t);
            }
        }

        private static boolean matchPrefix(String s, List<String> prefixes) {
            for (String p : prefixes) if (s.startsWith(p)) return true;
            return false;
        }
        private static boolean containsAny(String s, List<String> hints) {
            String l = s.toLowerCase();
            for (String h : hints) if (l.contains(h.toLowerCase())) return true;
            return false;
        }
        private Locator() {}
    }

    // ==================== 路径仓库 ====================

    public static final class Store {
        private static final Set<String> LIVE = ConcurrentHashMap.newKeySet();
        private static final ConcurrentHashMap<String, String> MEM = new ConcurrentHashMap<>();
        private static final String SP = "express_jump_route_cache";

        private static boolean looksLikePath(String s) {
            if (s == null) return false;
            int len = s.length();
            return len >= 4 && len <= 256 && (s.contains("/") || s.contains("."));
        }

        public static void record(String candidate) {
            try { if (looksLikePath(candidate)) LIVE.add(candidate); } catch (Throwable ignored) {}
        }

        /** 被动捕获：Hook注册方法，String实参即候选路径 */
        public static void hookRegisters(Locator.Handle h) {
            for (final Method m : h.registerMethods) {
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                for (Object arg : param.args) {
                                    if (arg instanceof String) record((String) arg);
                                }
                            } catch (Throwable ignored) {}
                        }
                    });
                } catch (Throwable ignored) { /* 单个hook失败跳过 */ }
            }
        }

        /** 主动收割：反射遍历路由单例内部Map（路由表本质），深度限制防循环 */
        public static void harvest(Locator.Handle h) {
            Object root = h.routerInstance != null ? h.routerInstance : h.routerClass;
            Set<Object> visited = Collections.newSetFromMap(new ConcurrentHashMap<Object, Boolean>());
            walk(root, h.routerClass, 0, 3, visited);
        }

        private static void walk(Object obj, Class<?> clz, int depth, int max, Set<Object> visited) {
            if (obj == null || depth > max || !visited.add(obj)) return;
            try {
                for (Field f : clz.getDeclaredFields()) {
                    try {
                        f.setAccessible(true);
                        Object val;
                        try { val = f.get(obj); }
                        catch (IllegalArgumentException e) { val = f.get(null); } // 静态字段
                        if (val instanceof java.util.Map) {
                            java.util.Map<?, ?> map = (java.util.Map<?, ?>) val;
                            for (Object k : map.keySet()) {
                                if (k instanceof String) record((String) k);
                            }
                            for (Object v : map.values()) {
                                walk(v, v.getClass(), depth + 1, max, visited);
                            }
                        }
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}
        }

        /** 关键词打分：越靠前权重越高，同分取更短路径 */
        public static String matchLive(String[] keywords) {
            if (keywords == null || keywords.length == 0) return null;
            String best = null;
            int bestScore = 0;
            for (String path : LIVE) {
                String lower = path.toLowerCase(Locale.ROOT);
                int score = 0;
                for (int i = 0; i < keywords.length; i++) {
                    if (lower.contains(keywords[i].toLowerCase(Locale.ROOT))) {
                        score += (keywords.length - i) * 10;
                    }
                }
                if (score > bestScore
                        || (score == bestScore && score > 0 && best != null && path.length() < best.length())) {
                    bestScore = score;
                    best = path;
                }
            }
            return bestScore > 0 ? best : null;
        }

        public static String getCached(Context ctx, String pkg, long ver, String featureId) {
            String key = pkg + "_" + ver + "_" + featureId;
            String hit = MEM.get(key);
            if (hit != null) return hit;
            try {
                hit = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getString(key, null);
                if (hit != null) MEM.put(key, hit);
            } catch (Throwable ignored) {}
            return hit;
        }

        public static void putCached(Context ctx, String pkg, long ver, String featureId, String path) {
            String key = pkg + "_" + ver + "_" + featureId;
            MEM.put(key, path);
            try {
                ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().putString(key, path).apply();
            } catch (Throwable ignored) {}
        }

        private Store() {}
    }

    private Route() {}
}
