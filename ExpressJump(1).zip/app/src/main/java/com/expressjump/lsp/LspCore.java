package com.expressjump.lsp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 平台配置层：全部为特征词/关键词，零硬编码类名、方法名、页面路径。
 * 新增APP = Registry.all() 里加一行，核心代码零改动。
 */
public final class LspCore {

    public static final class Config {
        public final String appName, packageName;
        public final List<String> scanPrefixes, routerNameHints, navMethodHints,
                registerHints, splashHints;
        public final Map<String, String[]> featureKeywords; // 功能ID → 关键词（按优先级）
        public final String[] hubKeywords;      // 二级兜底：快递主页
        public final String[] profileKeywords;  // 三级兜底：个人中心
        public final String[] urlSchemes;

        Config(String appName, String packageName,
               List<String> scanPrefixes, List<String> routerNameHints,
               List<String> navMethodHints, List<String> registerHints,
               List<String> splashHints, Map<String, String[]> featureKeywords,
               String[] hubKeywords, String[] profileKeywords, String[] urlSchemes) {
            this.appName = appName; this.packageName = packageName;
            this.scanPrefixes = scanPrefixes; this.routerNameHints = routerNameHints;
            this.navMethodHints = navMethodHints; this.registerHints = registerHints;
            this.splashHints = splashHints; this.featureKeywords = featureKeywords;
            this.hubKeywords = hubKeywords; this.profileKeywords = profileKeywords;
            this.urlSchemes = urlSchemes;
        }
    }

    public static final class Registry {
        public static List<Config> all() {
            return Arrays.asList(cainiao(), taobao(), pdd(), douyin());
        }

        private static Config cainiao() {
            Map<String, String[]> f = new HashMap<>();
            f.put("cainiao_identity_code", new String[]{
                    "identity-code", "identitycode", "取件码", "身份码", "pickupcode", "barcode"});
            return new Config("菜鸟", "com.cainiao.wireless",
                    Arrays.asList("com.cainiao", "com.taobao.cainiao"),
                    Arrays.asList("router", "route", "navigat", "jump", "dispatch"),
                    Arrays.asList("navigate", "open", "start", "go", "router", "to"),
                    Arrays.asList("register", "put", "add", "route"),
                    Arrays.asList("splash", "welcome", "launch", "adactivity"),
                    f,
                    new String[]{"我的快递", "快递", "express", "pickup", "包裹", "home"},
                    new String[]{"个人中心", "我的", "mine", "profile", "user"},
                    new String[]{"cainiao://"});
        }

        private static Config taobao() {
            Map<String, String[]> f = new HashMap<>();
            f.put("tb_identity_code", new String[]{
                    "identity-code", "last-mile", "end-collect-platform", "身份码", "取件码"});
            f.put("tb_wait_pickup", new String[]{
                    "wait-pickup", "waitpickup", "待取件", "我的快递", "express", "logistics"});
            return new Config("淘宝", "com.taobao.taobao",
                    Arrays.asList("com.taobao"),
                    Arrays.asList("router", "route", "navigat", "jump", "nav", "weex"),
                    Arrays.asList("navigate", "open", "start", "go", "router", "jump"),
                    Arrays.asList("register", "put", "add", "route"),
                    Arrays.asList("splash", "welcome", "launch", "ad", "guide"),
                    f,
                    new String[]{"待取件", "我的快递", "快递", "express", "logistics", "wuliu"},
                    new String[]{"个人中心", "我的淘宝", "我的", "mine", "profile", "user"},
                    new String[]{"tbopen://", "taobao://"});
        }

        private static Config pdd() {
            Map<String, String[]> f = new HashMap<>();
            f.put("pdd_identity_code", new String[]{
                    "pickup-code", "pickupcode", "身份码", "取件码", "qrcode"});
            f.put("pdd_wait_pickup", new String[]{
                    "express-list", "expresslist", "待取快递", "我的快递", "快递"});
            return new Config("拼多多", "com.xunmeng.pinduoduo",
                    Arrays.asList("com.xunmeng"),
                    Arrays.asList("router", "route", "navigat", "jump", "interceptor"),
                    Arrays.asList("navigate", "open", "start", "go", "router", "forward"),
                    Arrays.asList("register", "put", "add", "route"),
                    Arrays.asList("splash", "welcome", "launch", "ad"),
                    f,
                    new String[]{"待取快递", "我的快递", "快递", "express", "logistics"},
                    new String[]{"个人中心", "我的", "mine", "profile", "user"},
                    new String[]{"pinduoduo://"});
        }

        private static Config douyin() {
            Map<String, String[]> f = new HashMap<>();
            f.put("dy_wait_pickup", new String[]{
                    "logistics", "express", "待取件", "我的快递", "快递", "order"});
            return new Config("抖音", "com.ss.android.ugc.aweme",
                    Arrays.asList("com.ss.android"),
                    Arrays.asList("router", "route", "navigat", "jump", "schema"),
                    Arrays.asList("navigate", "open", "start", "go", "router", "openurl"),
                    Arrays.asList("register", "put", "add", "route"),
                    Arrays.asList("splash", "welcome", "launch", "ad"),
                    f,
                    new String[]{"我的快递", "待取件", "快递", "logistics", "express"},
                    new String[]{"个人中心", "我的", "mine", "profile", "user", "setting"},
                    new String[]{"snssdk1128://", "douyin://"});
        }
    }

    private LspCore() {}
}
