package com.expressjump.lsp;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;

import com.expressjump.core.Kit;

import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 注入编排（每个目标APP执行一次）：
 *  1) Hook Application.onCreate —— 进程起点，预初始化路由环境；
 *  2) 注册内部跳转广播（NOT_EXPORTED，仅本进程可达）；
 *  3) Hook Launcher onCreate —— 冷启动通道（动态获取组件名，消费宿主Intent的extra）；
 *  4) 异步定位路由 + 安装路径捕获 + 闪屏跳过。
 * 收到请求：立即回ACK → 路由就绪直接执行回终态，未就绪挂起待就绪后补发终态。
 * 所有步骤独立try-catch，任何失败仅打日志，绝不影响宿主APP。
 */
public final class Hook {

    public static void install(final XC_LoadPackage.LoadPackageParam lpparam, final LspCore.Config cfg) {
        try {
            XposedHelpers.findAndHookMethod("android.app.Application", lpparam.classLoader,
                    "onCreate", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                Application app = (Application) param.thisObject;
                                RuntimeState state = RuntimeState.get(cfg.packageName);
                                if (state.bootstrapped) return;
                                state.bootstrapped = true;
                                bootstrap(app, cfg, state);
                            } catch (Throwable t) {
                                Kit.Logger.e("[" + cfg.appName + "] Application注入失败", t);
                            }
                        }
                    });
        } catch (Throwable t) {
            Kit.Logger.e("[" + cfg.appName + "] Application hook失败", t);
        }
    }

    private static void bootstrap(final Application app, final LspCore.Config cfg,
                                  final RuntimeState state) {
        // 1) 广播通道
        try {
            BroadcastReceiver receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    try {
                        final String feature = intent.getStringExtra(Kit.Bridge.EXTRA_FEATURE);
                        if (feature == null) return;
                        report(context, cfg, feature, true); // ACK：进程存活确认
                        executeWithReport(context, cfg, state, feature);
                    } catch (Throwable t) {
                        Kit.Logger.e("[" + cfg.appName + "] 广播处理异常", t);
                    }
                }
            };
            IntentFilter filter = new IntentFilter(Kit.Bridge.ACTION_JUMP);
            if (Build.VERSION.SDK_INT >= 33) {
                app.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                app.registerReceiver(receiver, filter);
            }
        } catch (Throwable t) {
            Kit.Logger.e("[" + cfg.appName + "] 广播注册失败", t);
        }

        // 2) 冷启动通道：动态取Launcher组件名（零硬编码），hook其onCreate
        try {
            Intent launchIntent = app.getPackageManager().getLaunchIntentForPackage(cfg.packageName);
            if (launchIntent != null && launchIntent.getComponent() != null) {
                String launcherName = launchIntent.getComponent().getClassName();
                Class<?> launcherClz = Class.forName(launcherName, false, app.getClassLoader());
                XposedBridge.hookMethod(
                        XposedHelpers.findMethodExact(launcherClz, "onCreate", Bundle.class),
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                try {
                                    Activity a = (Activity) param.thisObject;
                                    Intent intent = a.getIntent();
                                    if (intent != null && intent.hasExtra(Kit.Bridge.EXTRA_FEATURE)) {
                                        String feature = intent.getStringExtra(Kit.Bridge.EXTRA_FEATURE);
                                        intent.removeExtra(Kit.Bridge.EXTRA_FEATURE); // 防旋转重建重复触发
                                        executeWithReport(a, cfg, state, feature);
                                    }
                                } catch (Throwable t) {
                                    Kit.Logger.e("[" + cfg.appName + "] Launcher extra消费异常", t);
                                }
                            }
                        });
            }
        } catch (Throwable t) {
            Kit.Logger.e("[" + cfg.appName + "] Launcher hook失败（冷启动降级为纯广播）", t);
        }

        // 3) 闪屏跳过
        Jump.SplashSkipper.install(app.getClassLoader(), cfg);

        // 4) 异步路由定位（不阻塞主线程启动）
        new Thread(() -> {
            try {
                Route.Locator.Handle handle = Route.Locator.locate(app, cfg);
                if (handle != null) {
                    state.handle = handle;
                    Route.Store.hookRegisters(handle);
                    Route.Store.harvest(handle);
                    state.routerReady.set(true);
                    Kit.Logger.i("[" + cfg.appName + "] 路由就绪");
                    Pending p = state.pending;   // 就绪后补发挂起的跳转
                    if (p != null) {
                        state.pending = null;
                        boolean ok = Jump.Coordinator.execute(p.ctx, cfg, state, p.feature);
                        report(p.ctx, cfg, p.feature, ok);
                    }
                }
            } catch (Throwable t) {
                Kit.Logger.e("[" + cfg.appName + "] 路由定位异常", t);
            }
        }, "ExpressJump-Locator").start();
    }

    /** 执行+回终态；路由未就绪则挂起，由定位线程补发终态 */
    private static void executeWithReport(Context ctx, LspCore.Config cfg,
                                          RuntimeState state, String feature) {
        try {
            if (state.routerReady.get() && state.handle != null) {
                boolean ok = Jump.Coordinator.execute(ctx, cfg, state, feature);
                report(ctx, cfg, feature, ok);
            } else {
                state.pending = new Pending(ctx, feature);
                Kit.Logger.i("[" + cfg.appName + "] 路由未就绪，跳转挂起: " + feature);
            }
        } catch (Throwable t) {
            Kit.Logger.e("[" + cfg.appName + "] executeWithReport异常", t);
            report(ctx, cfg, feature, false);
        }
    }

    /** 回发终态（ok=true 宿主停止等待；false 宿主立即降级Deeplink） */
    private static void report(Context ctx, LspCore.Config cfg, String feature, boolean ok) {
        try {
            ctx.sendBroadcast(new Intent(Kit.Bridge.ACTION_RESULT)
                    .setPackage(Kit.Bridge.HOST_PACKAGE)
                    .putExtra(Kit.Bridge.EXTRA_FEATURE, feature)
                    .putExtra(Kit.Bridge.EXTRA_OK, ok));
        } catch (Throwable t) {
            Kit.Logger.e("[" + cfg.appName + "] 回执发送失败", t);
        }
    }

    static final class Pending {
        final Context ctx; final String feature;
        Pending(Context c, String f) { ctx = c; feature = f; }
    }

    static final class RuntimeState {
        volatile boolean bootstrapped;
        volatile Route.Locator.Handle handle;
        final AtomicBoolean routerReady = new AtomicBoolean(false);
        volatile Pending pending;

        private static final java.util.concurrent.ConcurrentHashMap<String, RuntimeState> ALL
                = new java.util.concurrent.ConcurrentHashMap<>();
        static RuntimeState get(String pkg) {
            RuntimeState s = new RuntimeState();
            RuntimeState prev = ALL.putIfAbsent(pkg, s);
            return prev != null ? prev : s;
        }
    }

    private Hook() {}
}
