package com.expressjump.lsp;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import com.expressjump.core.Kit;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * 执行层：
 * Engine        直接调用路由单例跳转方法，绕开DeepLink协议/来源校验；
 *               枚举5种常见签名自动尝试，失败静默换下一个，绝不抛异常。
 * SplashSkipper 类名命中闪屏特征词的Activity延迟150ms自动finish（每实例一次）。
 * Coordinator   三级兜底：功能路径 → 快递主页 → 个人中心，绝不直接停首页。
 */
public final class Jump {

    public static final class Engine {
        public static boolean jump(Context ctx, Route.Locator.Handle h,
                                   LspCore.Config cfg, String rawPath) {
            if (h == null || h.jumpMethod == null) return false;
            for (String path : normalize(cfg, rawPath)) {
                if (trySignatures(ctx, h, path)) {
                    Kit.Logger.i("[" + cfg.appName + "] 跳转成功: " + path);
                    return true;
                }
            }
            return false;
        }

        /** 裸path / 去前导斜杠 / 带scheme 多形态 */
        private static List<String> normalize(LspCore.Config cfg, String raw) {
            List<String> out = new ArrayList<>();
            String trimmed = raw.startsWith("/") ? raw.substring(1) : raw;
            out.add(raw);
            if (!out.contains(trimmed)) out.add(trimmed);
            for (String scheme : cfg.urlSchemes) {
                String s = scheme.endsWith("://") ? scheme : scheme + "://";
                if (!out.contains(s + trimmed)) out.add(s + trimmed);
            }
            return out;
        }

        private static boolean trySignatures(Context ctx, Route.Locator.Handle h, String path) {
            Method m = h.jumpMethod;
            Bundle bundle = new Bundle();
            Object[][] variants = {
                    {path},
                    {ctx, path},
                    {path, bundle},
                    {ctx, path, bundle},
                    {Uri.parse(path.contains("://") ? path : "router://" + path)},
            };
            for (Object[] args : variants) {
                try {
                    Method target = (args.length == m.getParameterTypes().length) ? m : findAlt(h, args.length);
                    if (target == null) continue;
                    target.setAccessible(true);
                    Object recv = Modifier.isStatic(target.getModifiers()) ? null : h.routerInstance;
                    Object result = target.invoke(recv, coerce(target, args));
                    if (!(result instanceof Boolean) || (Boolean) result) return true;
                } catch (Throwable ignored) {}
            }
            return false;
        }

        private static Method findAlt(Route.Locator.Handle h, int paramCount) {
            try {
                for (Method mm : h.routerClass.getDeclaredMethods()) {
                    if (!Modifier.isPublic(mm.getModifiers())) continue;
                    Class<?>[] pts = mm.getParameterTypes();
                    if (pts.length == paramCount
                            && (pts[0] == String.class || pts[0] == Context.class || pts[0] == Uri.class)) {
                        return mm;
                    }
                }
            } catch (Throwable ignored) {}
            return null;
        }

        private static Object[] coerce(Method m, Object[] args) {
            Class<?>[] pts = m.getParameterTypes();
            Object[] out = new Object[args.length];
            for (int i = 0; i < args.length; i++) {
                Object a = args[i];
                if (a == null || pts[i].isInstance(a)) out[i] = a;
                else if (a instanceof String && pts[i] == Uri.class) out[i] = Uri.parse((String) a);
                else if (a instanceof Context) out[i] = ((Context) a).getApplicationContext();
                else out[i] = a;
            }
            return out;
        }
        private Engine() {}
    }

    public static final class SplashSkipper {
        private static final Set<Activity> FINISHED =
                Collections.synchronizedSet(Collections.newSetFromMap(new IdentityHashMap<Activity, Boolean>()));

        public static void install(ClassLoader cl, final LspCore.Config cfg) {
            try {
                XposedHelpers.findAndHookMethod("android.app.Activity", cl, "onResume",
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) {
                                try {
                                    final Activity a = (Activity) param.thisObject;
                                    String name = a.getClass().getName().toLowerCase();
                                    for (String hint : cfg.splashHints) {
                                        if (name.contains(hint.toLowerCase()) && FINISHED.add(a)) {
                                            a.getWindow().getDecorView().postDelayed(() -> {
                                                try { a.finish(); } catch (Throwable ignored) {}
                                                FINISHED.remove(a);
                                            }, 150);
                                            break;
                                        }
                                    }
                                } catch (Throwable ignored) {}
                            }
                        });
            } catch (Throwable t) {
                Kit.Logger.e("[" + cfg.appName + "] 闪屏跳过安装失败", t);
            }
        }
        private SplashSkipper() {}
    }

    public static final class Coordinator {
        /**
         * 三级兜底（任何一级失败自动降级）：
         *   一级 功能专属路径 → 二级 快递主页 → 三级 个人中心
         * 路径来源：磁盘缓存(按版本键控) > 实时路径池匹配
         */
        public static boolean execute(Context ctx, LspCore.Config cfg,
                                      Hook.RuntimeState state, String featureId) {
            try {
                long ver = version(ctx);
                String path;

                path = resolve(ctx, cfg, ver, featureId, cfg.featureKeywords.get(featureId));
                if (path != null && Engine.jump(ctx, state.handle, cfg, path)) return true;

                path = resolve(ctx, cfg, ver, featureId + "#hub", cfg.hubKeywords);
                if (path != null && Engine.jump(ctx, state.handle, cfg, path)) return true;

                path = resolve(ctx, cfg, ver, featureId + "#profile", cfg.profileKeywords);
                if (path != null && Engine.jump(ctx, state.handle, cfg, path)) return true;

                Kit.Logger.i("[" + cfg.appName + "] 三级兜底均未命中: " + featureId);
                return false;
            } catch (Throwable t) {
                Kit.Logger.e("[" + cfg.appName + "] execute异常（已吞掉）", t);
                return false;
            }
        }

        private static String resolve(Context ctx, LspCore.Config cfg, long ver,
                                      String cacheId, String[] keywords) {
            if (keywords == null) return null;
            String path = Route.Store.getCached(ctx, cfg.packageName, ver, cacheId);
            if (path != null) return path;
            path = Route.Store.matchLive(keywords);
            if (path != null) {
                Route.Store.putCached(ctx, cfg.packageName, ver, cacheId, path);
                return path;
            }
            return null;
        }

        private static long version(Context ctx) {
            try {
                return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).getLongVersionCode();
            } catch (Throwable t) { return -1; }
        }
        private Coordinator() {}
    }

    private Jump() {}
}
