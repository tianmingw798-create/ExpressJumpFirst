package com.expressjump.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.expressjump.R;
import com.expressjump.XposedEntry;
import com.expressjump.core.Kit;
import com.google.android.material.textfield.TextInputEditText;

/**
 * 快捷面板：短按 = 内部路由直达（LSP激活时），失败/超时/未激活自动降级Deeplink；
 *          长按 = 编辑该功能入口链接。
 * 降级仲裁：LSP未激活 → 立即Deeplink；激活 → 等回执（ok=false或8秒超时 → Deeplink）。
 */
public class MainActivity extends AppCompatActivity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ResultReceiver receiver;
    private String pendingFeature;
    private Runnable fallbackTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        registerResultReceiver();
        bindCard(R.id.card_cainiao_id, "cainiao_identity_code");
        bindCard(R.id.card_tb_id, "tb_identity_code");
        bindCard(R.id.card_pdd_id, "pdd_identity_code");
        bindCard(R.id.card_tb_wait, "tb_wait_pickup");
        bindCard(R.id.card_pdd_wait, "pdd_wait_pickup");
        bindCard(R.id.card_dy_wait, "dy_wait_pickup");
    }

    private void bindCard(int viewId, final String featureId) {
        View card = findViewById(viewId);
        final Kit.Feature f = Kit.Feature.byId(featureId);
        if (card == null || f == null) return;
        card.setOnClickListener(v -> jump(f));
        card.setOnLongClickListener(v -> { showEditDialog(f); return true; });
    }

    private void jump(Kit.Feature f) {
        cancelFallback();

        if (!XposedEntry.isModuleActive()) {          // LSP未激活：直接降级，功能照常可用
            Kit.Logger.i("LSP未激活，直接Deeplink: " + f.id);
            Kit.Deeplink.jump(this, f);
            return;
        }

        pendingFeature = f.id;

        // 通道1：热启动广播（目标进程在跑时立即生效）
        sendBroadcast(new Intent(Kit.Bridge.ACTION_JUMP)
                .setPackage(f.pkg)
                .putExtra(Kit.Bridge.EXTRA_FEATURE, f.id));

        // 无ACK → 冷启动：通道2，带参拉起Launcher
        handler.postDelayed(() -> {
            if (f.id.equals(pendingFeature)) {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(f.pkg);
                    if (launch != null) {
                        launch.putExtra(Kit.Bridge.EXTRA_FEATURE, f.id)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(launch);
                    } else {
                        Kit.Deeplink.jump(MainActivity.this, f);
                        pendingFeature = null;
                    }
                } catch (Throwable t) {
                    Kit.Deeplink.jump(MainActivity.this, f);
                    pendingFeature = null;
                }
            }
        }, Kit.Bridge.ACK_TIMEOUT_MS);

        // 终态总超时兜底
        fallbackTask = () -> {
            if (f.id.equals(pendingFeature)) {
                Kit.Logger.i("内部跳转超时，降级Deeplink: " + f.id);
                Kit.Deeplink.jump(MainActivity.this, f);
                pendingFeature = null;
            }
        };
        handler.postDelayed(fallbackTask, Kit.Bridge.RESULT_TIMEOUT_MS);
    }

    private void cancelFallback() {
        if (fallbackTask != null) handler.removeCallbacks(fallbackTask);
        pendingFeature = null;
    }

    // ---------- 回执接收（校验发送方，防伪造） ----------

    private void registerResultReceiver() {
        receiver = new ResultReceiver();
        IntentFilter filter = new IntentFilter(Kit.Bridge.ACTION_RESULT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
    }

    private class ResultReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String sender = getSendingPackage();
                boolean trusted = "com.taobao.taobao".equals(sender)
                        || "com.xunmeng.pinduoduo".equals(sender)
                        || "com.ss.android.ugc.aweme".equals(sender)
                        || "com.cainiao.wireless".equals(sender);
                if (!trusted) return;

                String feature = intent.getStringExtra(Kit.Bridge.EXTRA_FEATURE);
                if (feature == null || !feature.equals(pendingFeature)) return;
                cancelFallback();

                if (intent.getBooleanExtra(Kit.Bridge.EXTRA_OK, false)) {
                    Kit.Logger.i("内部直达成功: " + feature);
                } else {
                    Kit.Logger.i("内部直达失败，降级Deeplink: " + feature);
                    Kit.Feature f = Kit.Feature.byId(feature);
                    if (f != null) Kit.Deeplink.jump(MainActivity.this, f);
                }
            } catch (Throwable t) {
                Kit.Logger.e("回执处理异常", t);
            }
        }
    }

    // ---------- 长按编辑 ----------

    private void showEditDialog(final Kit.Feature f) {
        try {
            View view = getLayoutInflater().inflate(R.layout.dialog_edit_link, null);
            final TextInputEditText et = view.findViewById(R.id.et_link);
            String current = Kit.Store.getLink(this, f);
            et.setText(current);
            et.setSelection(current.length());

            new AlertDialog.Builder(this)
                    .setTitle("「" + f.label + "」自定义入口链接")
                    .setView(view)
                    .setPositiveButton("保存", (d, w) -> {
                        Kit.Store.saveLink(this, f, et.getText() == null ? "" : et.getText().toString());
                        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("恢复默认", (d, w) -> {
                        Kit.Store.saveLink(this, f, "");
                        Toast.makeText(this, "已恢复默认链接", Toast.LENGTH_SHORT).show();
                    })
                    .setNeutralButton("取消", null)
                    .show();
        } catch (Throwable t) {
            Kit.Logger.e("编辑对话框异常", t);
        }
    }

    @Override
    protected void onDestroy() {
        cancelFallback();
        try { unregisterReceiver(receiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
