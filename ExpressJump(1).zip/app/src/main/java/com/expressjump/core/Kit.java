package com.expressjump.core;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import de.robv.android.xposed.XposedBridge;

/**
 * 宿主侧基础件合集：
 *  Logger   双通道日志（logcat + Xposed，LSP未激活时Xposed调用被try-catch吞掉）
 *  Bridge   宿主 ↔ 注入侧 广播协议常量
 *  Feature  6个功能定义（id/包名/默认Deeplink）
 *  Store    自定义链接本地存储（SharedPreferences，留空恢复默认）
 *  Deeplink 降级跳转（优先限定包名，失败放开交给系统解析）
 */
public final class Kit {

    public static final class Logger {
        private static final String TAG = "ExpressJump";
        public static void i(String msg) {
            try { Log.i(TAG, msg); } catch (Throwable ignored) {}
            try { XposedBridge.log("[ExpressJump] " + msg); } catch (Throwable ignored) {}
        }
        public static void e(String msg, Throwable t) {
            try { Log.e(TAG, msg, t); } catch (Throwable ignored) {}
            try { XposedBridge.log("[ExpressJump][ERR] " + msg + " -> " + t); } catch (Throwable ignored) {}
        }
    }

    public static final class Bridge {
        public static final String HOST_PACKAGE = "com.expressjump";
        public static final String ACTION_JUMP   = "com.expressjump.action.JUMP";   // 宿主→目标：请求内部跳转
        public static final String ACTION_RESULT = "com.expressjump.action.RESULT"; // 目标→宿主：终态回执
        public static final String EXTRA_FEATURE = "feature";
        public static final String EXTRA_OK      = "ok";
        public static final long ACK_TIMEOUT_MS    = 700;   // 无ACK=冷启动，带参拉起Launcher
        public static final long RESULT_TIMEOUT_MS = 8000;  // 终态总超时，超时强制降级
    }

    public static final class Feature {
        public final String id, label, pkg, defaultLink;
        private Feature(String id, String label, String pkg, String defaultLink) {
            this.id = id; this.label = label; this.pkg = pkg; this.defaultLink = defaultLink;
        }
        public static final List<Feature> ALL = Collections.unmodifiableList(Arrays.asList(
                new Feature("cainiao_identity_code", "菜鸟身份码",
                        "com.cainiao.wireless", "cainiao://page/identity_code"),
                new Feature("tb_identity_code", "淘宝身份码",
                        "com.taobao.taobao", "tbopen://m.taobao.com/tbcorp/end_collect_platform"),
                new Feature("pdd_identity_code", "拼多多身份码",
                        "com.xunmeng.pinduoduo", "pinduoduo://com.xunmeng.pinduoduo/pickup_code"),
                new Feature("tb_wait_pickup", "淘宝待取快递",
                        "com.taobao.taobao", "tbopen://m.taobao.com/wait_pickup"),
                new Feature("pdd_wait_pickup", "拼多多待取快递",
                        "com.xunmeng.pinduoduo", "pinduoduo://com.xunmeng.pinduoduo/express_list"),
                new Feature("dy_wait_pickup", "抖音待取快递",
                        "com.ss.android.ugc.aweme", "snssdk1128://logistics")
        ));
        public static Feature byId(String id) {
            for (Feature f : ALL) if (f.id.equals(id)) return f;
            return null;
        }
    }

    public static final class Store {
        private static final String SP = "express_jump_links";
        public static String getLink(Context ctx, Feature f) {
            try {
                String custom = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getString(f.id, null);
                return (custom == null || custom.trim().isEmpty()) ? f.defaultLink : custom.trim();
            } catch (Throwable t) { return f.defaultLink; }
        }
        public static void saveLink(Context ctx, Feature f, String link) {
            try {
                ctx.getSharedPreferences(SP, Context.MODE_PRIVATE)
                        .edit().putString(f.id, link == null ? "" : link.trim()).apply();
            } catch (Throwable ignored) {}
        }
    }

    public static final class Deeplink {
        public static void jump(Context ctx, Feature f) {
            String link = Store.getLink(ctx, f);
            try {
                ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setPackage(f.pkg));
            } catch (Throwable first) {
                try {
                    ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Throwable second) {
                    try { Toast.makeText(ctx, "未找到可处理该链接的应用", Toast.LENGTH_SHORT).show(); }
                    catch (Throwable ignored) {}
                    Logger.e("Deeplink失败: " + link, second);
                }
            }
        }
    }

    private Kit() {}
}
