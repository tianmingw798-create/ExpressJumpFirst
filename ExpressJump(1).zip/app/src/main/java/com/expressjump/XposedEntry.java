package com.expressjump;

import com.expressjump.core.Kit;
import com.expressjump.lsp.Hook;
import com.expressjump.lsp.LspCore;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** LSPosed标准入口：hook本包仅置激活标志（宿主降级仲裁依据）；4目标APP分发注入。 */
public class XposedEntry implements IXposedHookLoadPackage {

    private static volatile boolean sActive = false;

    /** 宿主进程内由本hook写入，无侵入检测LSP是否激活 */
    public static boolean isModuleActive() { return sActive; }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam.packageName == null) return;

        if ("com.expressjump".equals(lpparam.packageName)) {
            sActive = true;
            Kit.Logger.i("LSP 已激活（宿主进程）");
            return;
        }

        for (LspCore.Config cfg : LspCore.Registry.all()) {
            if (cfg.packageName.equals(lpparam.packageName)) {
                Kit.Logger.i("命中目标: " + cfg.appName);
                Hook.install(lpparam, cfg);
                return;
            }
        }
    }
}
