# 快递快捷跳转（ExpressJump）

一体化 APK：桌面快捷面板（6个功能按钮）+ LSPosed Xposed 模块。
- LSP 未激活：自动降级为普通 Deeplink 快捷工具，功能照常可用
- LSP 已激活：特征扫描定位目标APP路由单例，内部路由直达，解决外部 DeepLink 落首页问题

## 手机端构建 APK（无需电脑）

### 方式一：GitHub Actions 云端构建（推荐）

1. 手机浏览器打开 https://github.com 注册/登录
2. 右上角 `+` → `New repository` → 名字 `ExpressJump` → Public → Create
3. 上传本工程全部文件（保持目录结构）：
   - 手机装 MGit/Termux 用 git 推送；或
   - 浏览器打开仓库 → `Add file` → `Upload files`，把解压后的文件夹内容拖入
4. 上传后进入 `Actions` 标签页 → 左侧 `Build APK` → 右侧 `Run workflow`
5. 约 3-5 分钟出现绿色 ✓ → 点进去 → 页面底部 `Artifacts` → 下载 `ExpressJump-APK`
6. 解压得到 `app-debug.apk`，传到手机安装（需允许"安装未知应用"）

### 方式二：Android Studio（有电脑时）

1. Android Studio → Open 打开本工程目录
2. 等 Sync 完成（自动下载依赖，需要能访问 mavenCentral / api.xposed.info）
3. Build → Build APK(s) → 产物在 `app/build/outputs/apk/debug/app-debug.apk`

> 注：本工程未包含 gradle wrapper 二进制文件。Android Studio 首次 Sync 时若提示，
> 在 Settings → Build → Gradle 中选择 Gradle 8.7 即可；云端构建由 workflow 自动安装。

## LSPosed 激活步骤

1. 安装 APK，确认 LSPosed 框架已激活
2. LSPosed 管理器 → 模块 → 启用「快递快捷跳转」
3. 作用域勾选：淘宝、拼多多、抖音、菜鸟、本模块（com.expressjump）
4. 重启手机（或重启目标APP）
5. 验证：adb logcat -s ExpressJump:X 应看到 "LSP 已激活"、"命中目标"、"路由定位成功"

## 使用

- 短按按钮：内部路由直达（优先），失败自动降级 Deeplink
- 长按按钮：自定义该功能的入口 Deeplink（留空恢复默认）

## 维护

- 目标APP升级：无需任何操作（版本键控缓存自动失效重扫）
- 关键词失效：`adb logcat -s ExpressJump:X` 看捕获的路径池，
  修改 `app/src/main/java/com/expressjump/lsp/LspCore.java` 中对应平台的关键词数组即可
